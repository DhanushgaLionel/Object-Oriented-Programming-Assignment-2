/**
* @author AddYourNameHere YourBannerIDhere
*/

public class WireResistance {
 // Takes the write gauge and returns the corresponding wire diameter
 double computeDiameter(int wireGauge) {
 }
 // Takes the length and gauge of a piece of copper wire and returns the resistance of that wire.
 double computeCopperWireResistance(double length, int wireGauge) {
 }
 // Takes the length and gauge of a piece of aluminum wire and returns the resistance of that wire. The resistivity
 // of aluminum is 2.82 x 10−8 Ω m
 double computeAlumWireResistance(double length, int wireGauge){
 }
 public static void main(String[] args) {
 }
}
