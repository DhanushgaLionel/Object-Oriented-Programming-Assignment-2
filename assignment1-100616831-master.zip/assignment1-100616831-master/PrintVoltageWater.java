/**
* @author NEIL 12345
*/

public class PrintVoltageWater {
 public static void main(String[] args) {
 // Write your code here
 }
}
